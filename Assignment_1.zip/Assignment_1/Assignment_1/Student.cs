﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment_1
{
    class Student
    {
        private string _id;
        private string _fullName;
        private DateTime _dateOfBirth;
        private string _address;
        private string _phoneNumber;

        public Student() { }

        public Student(string id, string fullName, DateTime dateOfBirth, string address, string phoneNumber)
        {
            _id = id;
            _fullName = fullName;
            _dateOfBirth = dateOfBirth;
            _address = address;
            _phoneNumber = phoneNumber;
        }

        public string Id { get => _id; set => _id = value; }
        public string FullName { get => _fullName; set => _fullName = value; }
        public DateTime DateOfBirth { get => _dateOfBirth; set => _dateOfBirth = value; }
        public string Address { get => _address; set => _address = value; }
        public string PhoneNumber { get => _phoneNumber; set => _phoneNumber = value; }

        public void ViewInfo()
        {
            Console.WriteLine("Student: [{0} - {1} - {2} - {3} - {4}]", _id, _fullName, _dateOfBirth.ToString("dd/MM/yyyy"), _address, _phoneNumber);
        }
    }
}
