﻿using System;
using System.Collections.Generic;

namespace Assignment_1
{
    class Program
    {
        public static void ShowMenu()
        {
            Console.WriteLine("\n====== Management Student ======");
            Console.WriteLine("1. View All Students");
            Console.WriteLine("2. Add New Student");
            Console.WriteLine("3. Find Student By Id");
            Console.WriteLine("4. Update Student's Infomation By Id");
            Console.WriteLine("5. Exit\n");
        }

        static void Main(string[] args)
        {
            IList<Student> students = new List<Student>();

            int choice = -1;
            do
            {
                ShowMenu();
                Console.Write("===> Enter your choice: ");
                Int32.TryParse(Console.ReadLine(), out choice);
                switch (choice)
                {
                    case 1: StudentService.ViewAll(students); break;
                    case 2: StudentService.AddNewStudent(students); break;
                    case 3:
                        {
                            Console.Write("Enter Student's Id To Find: ");
                            String id = Console.ReadLine().ToUpper();
                            Student student = StudentService.FindStudentById(students, id);
                            if(student != null)
                            {
                                student.ViewInfo();
                            } else
                            {
                                Console.WriteLine("Can't not find student with Id: {0}", id);
                            }
                            break;
                        }
                    case 4:
                        {
                            Console.Write("Enter Student's Id To Find: ");
                            String id = Console.ReadLine().ToUpper();
                            StudentService.UpdateStudentsInfo(students, id);
                            break;
                        }
                }
            } while (choice != 5);
        }
    }
}
