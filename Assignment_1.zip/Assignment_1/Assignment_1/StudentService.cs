﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Assignment_1
{
    static class StudentService
    {
        /// <summary>
        /// View all infomation of student in list
        /// </summary>
        /// <param name="students"></param>
        public static void ViewAll(IList<Student> students)
        {
            if(students.Count == 0)
            {
                Console.WriteLine("There is not any students in list!");
                return;
            }

            foreach(Student student in students)
            {
                student.ViewInfo();
            }
        }

        /// <summary>
        /// Add new student into list students
        /// </summary>
        /// <param name="students"></param>
        public static void AddNewStudent(IList<Student> students)
        {
            string id, fullName, address, phoneNumber, tmpDateOfBirth;
            DateTime dateOfBirth;
            bool flag = false;
            do
            {
                Console.Write("Student's ID: ");
                id = Console.ReadLine().ToUpper();
                flag = IsContainId(students, id);
                if (flag)
                {
                    Console.WriteLine("Student's have been existed in list! ");
                }
            } while (flag);

            Console.Write("Student's Full Name: ");
            fullName = Console.ReadLine();

            do
            {
                Console.Write("Student's Date Of Birth, Following format (dd/MM/yyyy): ");
                tmpDateOfBirth = Console.ReadLine();
                flag = DateTime.TryParseExact(tmpDateOfBirth, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out dateOfBirth);
            } while (!flag);

            Console.Write("Student's Address: ");
            address = Console.ReadLine();

            Console.Write("Student's Phone Number: ");
            phoneNumber = Console.ReadLine();

            Student student = new Student(id, fullName, dateOfBirth, address, phoneNumber);
            students.Add(student);
        }

        /// <summary>
        /// Check if id has been existed
        /// </summary>
        /// <param name="students"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        private static bool IsContainId(IList<Student> students, string id)
        {
            foreach(Student student in students)
            {
                if (student.Id.Equals(id))
                {
                    return true;
                }
            }

            return false;
        } 

        /// <summary>
        /// Find student by student's id
        /// </summary>
        /// <param name="students"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public static Student FindStudentById(IList<Student> students, String id)
        {
            foreach(Student student in students)
            {
                if (student.Id.Equals(id))
                {
                    return student;
                }
            }
            return null;
        }

        /// <summary>
        /// Update student's info by id
        /// </summary>
        /// <param name="students"></param>
        /// <param name="id"></param>
        public static void UpdateStudentsInfo(IList<Student> students, String id)
        {
            if (!IsContainId(students, id))
            {
                Console.WriteLine("Can't not find student with Id: {0}", id);
                return;
            }

            string fullName, address, phoneNumber, tmpDateOfBirth;
            DateTime dateOfBirth;
            bool flag = false;
            Console.Write("Student's Full Name Update: ");
            fullName = Console.ReadLine();

            do
            {
                Console.Write("Student's Date Of Birth, Following format (dd/MM/yyyy) Update: ");
                tmpDateOfBirth = Console.ReadLine();
                flag = DateTime.TryParseExact(tmpDateOfBirth, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out dateOfBirth);
                if (!flag)
                {
                    Console.WriteLine("Incorrect Format dd/MM/yyyy, please try again!");
                }
            } while (!flag);

            Console.Write("Student's Address Update: ");
            address = Console.ReadLine();

            Console.Write("Student's Phone Number Update: ");
            phoneNumber = Console.ReadLine();

            Student student = new Student(id, fullName, dateOfBirth, address, phoneNumber);
            students[GetIndexOfStudentInList(students, id)] = student;

            Console.WriteLine("Update Student's Info Sucessed!");
        }

        /// <summary>
        /// Get index of student with specified id
        /// </summary>
        /// <param name="students"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        private static int GetIndexOfStudentInList(IList<Student> students, string id)
        {
            for(int i = 0; i < students.Count; i++)
            {
                if (students[i].Id.Equals(id))
                {
                    return i;
                }
            }
            return -1;
        }

    }
}
